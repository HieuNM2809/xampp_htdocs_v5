Đây là file trong zip.
Dùng test convert .zip qua MarkItDown.
